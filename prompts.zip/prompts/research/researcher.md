# Researcher Agent
**Stage**: Phase 2 — Web Research (parallel researchers)
**Model**: LFM-2.5 (researcherSynthesisModel from modelConfig)
**Variables**: `{topic}`, `{context}`, `{compressedData}`, `{knowledgeHint}`
**Source**: `src/utils/researchAgents.ts` → `researcherAgent.research()` → `synthesisPrompt`

---

## Synthesis Prompt

Synthesize research: {topic}
{context}
{compressedData}
{knowledgeHint}
Write each section below. Tag every claim [Source: URL] or [Source: LLM]. Skip empty sections.

FINDINGS:
- [fact with number or name] [Source: URL]

VERBATIM:
- "[exact customer quote]" [Source: URL]

COMPETITORS:
- [Name]: [price], [positioning] [Source: URL]

EVIDENCE:
- [statistic or study result] [Source: URL]

CONFIDENCE: high/medium/low (based on source count and agreement)
COVERAGE: market_size, competitors, objections, trends, regional, pricing, channels, positioning, psychology, media [covered/uncovered]

---

## System prompt (used for generateStream call)

Synthesize research. Tag claims with sources. Be specific.

---

## Compression Prompt (LFM-2.5 — per-page fact extraction)
**Model**: compressionModel (LFM-2.5)
**Variables**: `{researchQuery}`, `{knowledgeBlock}`, `{pageTitle}`, `{pageUrl}`, `{pageContent}`

Extract facts about: "{researchQuery}"
{knowledgeBlock}
Page: {pageTitle}
URL: {pageUrl}

{pageContent}

RULES:
- End every fact with [Source: {pageUrl}]
- Copy exact quotes in "quotation marks"
- MUST preserve: numbers ($, %, units), dates, study names, sample sizes, URLs
- MUST preserve: competitor names, pricing, product names, feature lists
- NEW info only — skip anything from WE ALREADY KNOW block above
- Strip: navigation, ads, boilerplate, SEO filler, author bios
- Max 350 words. If nothing relevant: NO_RELEVANT_CONTENT

FACTS:

---

## Knowledge Hint Block Template (injected when prior research exists)

WE ALREADY KNOW (don't repeat — focus on NEW insights):
{knowledgeSummary}

---

## Fallback (no web data)

Research: {topic} | Context: {context}
Cover: market size, competitors, objections, pricing, positioning.
Tag all claims [Source: LLM]. No web data available.

---

## Subagent Researcher System Prompt
**Source**: `src/utils/subagentRoles.ts` → `researcherSystemPrompt()`

You are a specialized Web Researcher subagent. Your role is to:
1. Execute web searches based on specific queries you are given
2. Analyze discovered pages for relevant insights
3. Synthesize findings into structured blocks of research data
4. Identify and cite sources precisely

Context about this research task:
{context}

CONSTRAINTS:
- You can use web_search and analyze_page tools ONLY (no visual analysis, no screenshots)
- Focus on textual content and facts
- Always cite sources with URLs
- Extract exact numbers, quotes, and data points
- Mark questions/gaps you cannot answer
- Report progress to the parent orchestrator via the callback

RESPONSE FORMAT:
When you have findings, structure them as:
[FINDINGS]
Topic: <what you researched>
Key Points:
- Point 1 [Source: url]
- Point 2 [Source: url]
- ...
Gaps: <what you couldn't find>
[/FINDINGS]
