# Visual Scout Agent
**Stage**: Phase 2 — Visual Competitive Intelligence (triggered by VISUAL_SCOUT directive)
**Model**: minicpm-v (vision), qwen3.5:9b (synthesis)
**Variables**: `{productDescription}`, `{brand}`, `{competitorAnalysisText}`
**Source**: `src/utils/visualScoutAgent.ts`

---

## Screenshot Analysis Prompt (vision model — per URL)

Competitor page for "{productDescription}". Extract exactly:
COLORS: [3-4 hex or named colors visible in hero/header/CTA]
LAYOUT: [hero-banner|split-screen|product-grid|long-scroll|minimal-centered]
TONE: [premium|clinical|playful|warm|edgy|trustworthy|corporate]
HERO: [what is the main visual — photo/illustration/video/gradient, subject matter]
SOCIAL_PROOF: [testimonials|star-ratings|badges|logos|user-counts|none]
TYPOGRAPHY: [headline style: bold-sans|elegant-serif|handwritten|minimal] [body: size estimate]
CTA: [button color] [text on button] [position: top|center|bottom|sticky] [shape: rounded|pill|square]
DIFFERENTIATOR: [1 sentence — what visual choice makes this brand stand out from others in this category]

---

**System prompt**: One line per label. No preamble. Exact values only.

---

## Visual Synthesis Prompt (qwen3.5:9b — across all analyses)

Visual strategy for {brand} ({productDescription}).

{competitorAnalysisText}

COMMON_PATTERNS:
- [what ALL/MOST competitors share visually]

VISUAL_GAPS:
- [what NONE do — unclaimed visual territory]

RECOMMENDED_DIFFERENTIATION:
- [how {brand} should look DIFFERENT — specific choices]

---

**System prompt**: Bullet points only. Be specific — name colors, layouts, patterns. No preamble.

---

## Single Image Analysis Prompt (for reflector ad-hoc use)

{analysisPrompt}

---

**System prompt**: Structured output only. Format: WHAT: [subject/content] WHERE: [layout/placement] STYLE: [visual treatment] MOOD: [emotional tone]. No preamble.

---

## Trigger Mechanism
Visual Scout is triggered when orchestrator or reflection agent output contains:
- `VISUAL_SCOUT: https://url1.com, https://url2.com`
- `AD_SCOUT: https://url1.com, https://url2.com`

Budget controlled by preset: `maxVisualBatches` and `maxVisualUrls`.
