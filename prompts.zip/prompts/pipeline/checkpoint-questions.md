# Interactive Mode Checkpoint Questions
**Stage**: Pipeline checkpoints (interactive mode only)
**Model**: GLM-4.7 (getModelForStage('research'))
**Variables**: `{campaignBrief}`, `{researchOutput}`, `{anglesOutput}`, `{copywritingOutput}`
**Source**: `src/utils/prompts.ts` → `getCheckpointQuestionPrompt()`

Used in interactive pipeline mode to generate strategic questions at 3 checkpoints.
Must output raw JSON (no markdown wrapping).

---

## System Prompt (shared across all checkpoints)

You generate ONE strategic question for the user at a pipeline checkpoint.
You MUST respond in valid JSON with this exact format:
{"question":"<your question>","options":["<option A>","<option B>","<option C>"],"context":"<1 sentence explaining why you're asking>"}

Rules:
- Question must be specific to this campaign, not generic
- Options must be distinct strategic directions, not just phrasing variations
- Each option should be 10-25 words max
- Context explains what gap or ambiguity you detected
- Do NOT wrap in markdown code blocks. Output raw JSON only.

---

## Checkpoint 1: Pre-Research

Campaign Brief:
{campaignBrief}

You are about to start the research phase. Look at this brief and identify the most important strategic ambiguity — something that would change HOW you research if you knew the answer.

Generate a question that helps you focus the research in the right direction. The 3 options should represent genuinely different research angles.

---

## Checkpoint 2: Mid-Pipeline

Campaign Brief:
{campaignBrief}

Research Output:
{researchOutput}

Angles Brainstorm:
{anglesOutput}

Research and angle brainstorming are complete. Next up: strategy evaluation and then copywriting.

Based on what the research and angles revealed, generate a question that helps choose the right STRATEGIC DIRECTION. The 3 options should represent different positioning choices.

---

## Checkpoint 3: Pre-Make

Campaign Brief:
{campaignBrief}

Copywriting Output:
{copywritingOutput}

Copy is ready. Next: production — generating actual ad creatives.

Generate a question about which COPY BLOCK or ANGLE to prioritize for production. The 3 options should represent different creative approaches.
